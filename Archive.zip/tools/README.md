# Anchorwork Tools Directory

This folder contains all shared and agent-specific tools for the Anchorwork multi-agent system.

## Structure

- **shared.py**: Contains generic, agent-agnostic utilities and tools. These include:
  - File IO helpers
  - Fun/generic tools (e.g., jokes, shanties)
  - Agent profile loader
  - Web search (SerpAPI)
  - Text utilities (summarize_text, paraphrase_text, grammar_check, markdown_to_html, html_to_markdown, fill_template, extract_keywords, split_text)
  - Tool registry and chaining
  - Rate limiting, retry, config loader
  - GCS integration
  - Plugin loader
  - Agent messaging, notification, health check
  - Education and self-improvement logic (append_education, recommend_to_agent, self_reflect, append_dynamic_identity_note, get_dynamic_identity_notes)

- **coder_tools.py**: Coder-specific tools for code generation, review, explanation, patching, and codebase search.
  - `generate_code`
  - `review_code`
  - `explain_code`
  - `patch_code`
  - `codebase_search`
  - `index_codebase`
  - `codebase_qa`
  - `log_debug_ritual`
  - `track_coding_mood`
  - `pair_program`
  - `teach_code`
  - `refactor_code`
  - `generate_tests`
  - `migrate_code`
  - `visualize_dependencies`
  - `security_scan`
  - `code_poetry`
  - `code_ritual_mode`
  - `ask_for_human_review`
  - `feedback_loop`
  - `github_pr`
  - `slack_answer`
  - `notify_owner`

- **firstmate_tools.py**: First Matey-specific tools for morale, encouragement, ritual scheduling, and LLM-powered affirmations and stories.
  - `boost_morale`
  - `schedule_ritual`
  - `emotional_check_in`
  - `team_building_activity`
  - `generate_shanty`
  - `send_affirmation`
  - `log_ritual_completion`
  - `gratitude_round`
  - `ritual_reminder`
  - `mood_trends`
  - `suggest_personalized_ritual`
  - `conflict_resolution_prompt`
  - `celebration_message`
  - `schedule_wellness_check`
  - `collect_feedback`
  - `motivational_quote`
  - `motivational_story`
  - `build_affirmation`
  - `random_act_of_kindness_prompt`
  - `log_morale_event`
  - `send_notification`

- **cartographer_tools.py**: Cartographer-specific tools for outline/map/structure generation, writing, editing, and cohesion analysis.
  - `generate_outline`
  - `generate_map`
  - `structure_document`
  - `orientation_prompt`
  - `visualize_journey`
  - `track_milestones`
  - `principle_reminder`
  - `decision_log`
  - `map_annotation`
  - `log_structure_event`
  - `send_notification`
  - `load_chapter_template`
  - `generate_chapter_section`
  - `generate_full_section`
  - `suggest_section_edits`
  - `analyze_cohesion`
  - `outline_to_full_draft`
  - `search_full_manual`
  - `generate_writing_outline`
  - `summarize_file`

- **alchemist_tools.py**: Alchemist-specific tools for metaphor/poetry generation, transformation, symbolic synthesis, emotional reframing, and ritual/metaphor archives.
  - `generate_metaphor`
  - `poetic_transformation`
  - `emotional_reframe`
  - `archive_ritual`
  - `retrieve_rituals`
  - `symbolic_synthesis`
  - `send_notification`
  - `dream_synthesis`
  - `symbol_dictionary`
  - `alchemy_of_conflict`
  - `ritual_generator`
  - `poetic_dialogue`
  - `emotion_to_element`
  - `symbolic_forecast`
  - `agent_integration`
  - `advanced_retrieve_rituals`
  - `summarize_symbolic_memory`

- **researcher_tools.py**: Researcher-specific tools for fact-checking, citation generation, archive search, annotation, synthesis, and notification.
  - `fact_check`
  - `generate_citation`
  - `archive_search`
  - `annotate_text`
  - `synthesize_findings`
  - `summarize_article`
  - `peer_review`
  - `send_notification`
  - `source_triangulation`
  - `reference_manager`
  - `literature_review`
  - `plagiarism_checker`
  - `research_question_generator`
  - `data_extraction`
  - `evidence_grading`
  - `fact_timeline`
  - `collaborative_annotation`
  - `research_reflection`

- **watcher_tools.py**: Watcher-specific tools for pattern/anomaly detection, emotional monitoring, trend analysis, alerting, silent logging, and reflection.
  - `detect_pattern`
  - `anomaly_alert`
  - `emotional_monitoring`
  - `trend_analysis`
  - `silent_log`
  - `watcher_reflection`
  - `send_notification`
  - `scheduled_pattern_watch`
  - `threshold_alerting`
  - `contextual_insight`
  - `event_correlation`
  - `silent_escalation`
  - `pattern_memory_visualization`
  - `agent_health_monitoring`
  - `minimalist_report`
  - `anomaly_feedback_loop`
  - `llm_watcher_self_reflection`
  - `sleep_wake_cycle_awareness`
  - `micro_pattern_detection`
  - `cross_agent_whisper`
  - `anomaly_root_cause_hypothesis`
  - `pattern_prediction`
  - `silent_vote`
  - `pattern_anomaly_tagging`
  - `watcher_digest`
  - `adaptive_sensitivity`
  - `watcher_coaching`

- **compass_tools.py**: Compass-specific tools for values alignment, affirmation, reflection, ethical scenario analysis, and notification.
  - `values_alignment`
  - `affirmation`
  - `reflection_prompt`
  - `ethical_scenario_analysis`
  - `moral_dilemma_generator`
  - `value_clarification`
  - `affirmation_builder`
  - `ethical_audit`
  - `compass_reflection`
  - `send_notification`

## Unified LLM, Memory, and Logging Integration

**All LLM-powered tools must:**
- Use `LLMClient` from `utils/llm_client.py` for all LLM calls (no direct OpenAI calls).
- Log every LLM call and tool action using `log_event` from the unified logger.
- Append every LLM call and tool action to the agent's memory pipeline using `get_memory_pipeline`.

**Example pattern:**
```python
from utils.llm_client import LLMClient
from utils.memory_pipeline import get_memory_pipeline
from logging import log_event

def my_tool(prompt: str, agent_id: str = "agent") -> str:
    llm = LLMClient()
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "my_tool"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "my_tool"})
    return response
```

**Best Practices:**
- Always use `LLMClient` for LLM calls to ensure model selection, logging, and error handling.
- Always log tool actions and LLM calls for auditability and debugging.
- Always append to the memory pipeline for agent context, learning, and continuity.
- Use agent/task-specific `agent_id` for all LLM, memory, and logging actions.
- See each tool file for more detailed examples and docstrings.

## Notes
- Optional dependencies for shared.py utilities (e.g., `markdown`, `html2text`) are listed in `requirements.txt`.
- All tools should be agent-agnostic unless there is a clear reason for specialization.
- For more details, see the docstrings in each tool file.
