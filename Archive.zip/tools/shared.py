"""
Shared utility functions for all Anchorwork agents.
No agent-specific logic or wording.

For logging, import log_event from the logging package:
from logging import log_event
"""

import os
import json
import re
import random
from datetime import datetime
from typing import Any, Dict, List, Callable, Optional, Tuple, Union
from pathlib import Path

import redis
from agentlogging.unified_logger import log_event

from utils.llm_client import LLMClient
from utils.memory_pipeline import get_memory_pipeline
from tools.cartographer_tools import generate_outline

# --- Redis Setup ---
def get_redis():
    # Centralized Redis connection (adjust for your cloud/stack config as needed)
    return redis.Redis(host=os.getenv("REDIS_HOST", "localhost"),
                       port=int(os.getenv("REDIS_PORT", 6379)),
                       db=int(os.getenv("REDIS_DB", 0)),
                       decode_responses=True)

r = get_redis()

# --- File IO ---
def read_project_file(file_path: str) -> str:
    """
    Read the contents of a file as a string.
    Args:
        file_path (str): Path to the file.
    Returns:
        str: File contents.
    Raises:
        FileNotFoundError: If the file does not exist.
        IOError: If the file cannot be read.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        log_event("file_read_error", {"file_path": file_path, "error": str(e)})
        raise

def save_modified_file(file_path: str, content: str) -> None:
    """
    Save content to a file, overwriting if it exists.
    Args:
        file_path (str): Path to the file.
        content (str): Content to write.
    Raises:
        IOError: If the file cannot be written.
    """
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
    except Exception as e:
        log_event("file_write_error", {"file_path": file_path, "error": str(e)})
        raise

# --- Fun/Generic Tools ---
def get_shanty() -> str:
    """
    Return a random sea shanty lyric.
    Returns:
        str: A shanty lyric.
    """
    shanties = [
        "What shall we do with a drunken sailor?",
        "Heave ho, raise the anchor high!",
        "Blow the man down, bullies, blow the man down!",
    ]
    return random.choice(shanties)

def get_joke() -> str:
    """
    Return a random programming or nautical joke.
    Returns:
        str: A joke.
    """
    jokes = [
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "Why did the function return early? It had a date with an exception.",
        "Why do ships never get lost? They follow their current.",
        "Why did the computer go to the doctor? It had a virus.",
        "Why did the database administrator leave their partner? Too many connections.",
        "Why did the scarecrow win an award? Because they were outstanding in their field.",
        "Why did the bicycle fall over? Because it was two-tired.",
        "Why can't you trust atoms? Because they make up everything.",
        "Why did the math book look sad? Because it had too many problems.",
        "Why did the chicken join a band? Because it had the drumsticks."
    ]
    return random.choice(jokes)

# --- Agent Profile ---
def load_agent_profile(agent_id: str) -> Dict[str, Any]:
    """
    Load an agent's profile from the profiles directory.
    Args:
        agent_id (str): The agent's ID.
    Returns:
        dict: The agent's profile, or empty dict if not found.
    """
    profile_path = f"profiles/{agent_id}.json"
    if os.path.exists(profile_path):
        try:
            with open(profile_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log_event("profile_load_error", {"agent_id": agent_id, "error": str(e)})
            return {}
    return {}

# --- Web Search (using SERPAPI as example) ---
def web_search(query: str, num_results: int = 3) -> List[Dict[str, str]]:
    """
    Perform a web search using SerpAPI.
    Args:
        query (str): Search query.
        num_results (int): Number of results to return.
    Returns:
        List[dict]: List of search results with title, url, and snippet.
    Raises:
        RuntimeError: If SERPAPI_KEY is not set or request fails.
    """
    import requests
    SERPAPI_KEY = os.getenv("SERPAPI_KEY")
    if not SERPAPI_KEY:
        log_event("web_search_error", {"query": query, "error": "SERPAPI_KEY not set"})
        raise RuntimeError("SERPAPI_KEY not set in environment.")
    params = {
        "q": query,
        "api_key": SERPAPI_KEY,
        "engine": "google",
        "num": num_results
    }
    try:
        resp = requests.get("https://serpapi.com/search", params=params)
        results = []
        if resp.status_code == 200:
            data = resp.json()
            for item in data.get("organic_results", [])[:num_results]:
                results.append({
                    "title": item.get("title", ""),
                    "url": item.get("link", ""),
                    "snippet": item.get("snippet", "")
                })
            return results
        else:
            log_event("web_search_error", {"query": query, "status": resp.status_code, "text": resp.text})
            return []
    except Exception as e:
        log_event("web_search_error", {"query": query, "error": str(e)})
        return []

# --- Text Utilities ---
def summarize_text(text: str, agent_id: str = "shared") -> str:
    llm = LLMClient()
    prompt = f"Summarize this:\n{text}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "summarize"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "summarize"})
    return response

def paraphrase_text(text: str, agent_id: str = "shared") -> str:
    llm = LLMClient()
    prompt = f"Paraphrase this:\n{text}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "paraphrase"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "paraphrase"})
    return response

def grammar_check(text: str, agent_id: str = "shared") -> str:
    llm = LLMClient()
    prompt = f"Check and correct the grammar in this text:\n{text}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "grammar_check"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "grammar_check"})
    return response

def markdown_to_html(md: str) -> str:
    try:
        import markdown
        return markdown.markdown(md)
    except ImportError:
        return "<p>" + md.replace("\n", "<br>") + "</p>"

def html_to_markdown(html: str) -> str:
    try:
        import html2text
        return html2text.html2text(html)
    except ImportError:
        return re.sub(r'<.*?>', '', html)

def fill_template(template: str, data: Dict[str, Any]) -> str:
    return template.format(**data)

def extract_keywords(text: str) -> List[str]:
    words = re.findall(r'\b\w+\b', text.lower())
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    stopwords = set(["the", "and", "is", "in", "to", "of", "a", "for", "on", "with", "as", "by", "at", "from"])
    keywords = [w for w in sorted(freq, key=freq.get, reverse=True) if w not in stopwords]
    return keywords[:5]

def split_text(text: str, max_length: int = 1000) -> List[str]:
    return [text[i:i+max_length] for i in range(0, len(text), max_length)]

# --- Tool Registry ---
_tool_registry: Dict[str, Callable] = {}

def register_tool(tool_name: str, func: Callable) -> None:
    _tool_registry[tool_name] = func

def list_tools() -> List[str]:
    return list(_tool_registry.keys())

def get_tool_doc(tool_name: str) -> str:
    func = _tool_registry.get(tool_name)
    return func.__doc__ if func else "No documentation available."

def tool_metadata(tool_name: str) -> Dict[str, Any]:
    func = _tool_registry.get(tool_name)
    return {"name": tool_name, "doc": func.__doc__ if func else None}

def call_tool(tool_name: str, *args, **kwargs) -> Any:
    func = _tool_registry.get(tool_name)
    if func:
        return func(*args, **kwargs)
    raise ValueError(f"Tool '{tool_name}' not found.")

def chain_tools(tools: List[Callable], input_data: Any) -> Any:
    data = input_data
    for tool in tools:
        data = tool(data)
    return data

# --- Rate Limiting (Redis-based) ---
def rate_limiter(key: str, limit: int, period: int) -> bool:
    current = r.incr(key)
    if current == 1:
        r.expire(key, period)
    return current <= limit

def retry_on_exception(func: Callable, retries: int = 3):
    for _ in range(retries):
        try:
            return func()
        except Exception:
            continue
    return None

# --- Config Loader ---
def load_config(config_path: str) -> Dict[str, Any]:
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

# --- GCS Integration ---
def upload_file_to_gcs(local_path: str, bucket: str, dest_path: str) -> None:
    from google.cloud import storage
    client = storage.Client()
    bucket_obj = client.bucket(bucket)
    blob = bucket_obj.blob(dest_path)
    blob.upload_from_filename(local_path)
    # For logging, use: from logging import log_event
    # log_event("gcs_upload", {"local_path": local_path, "bucket": bucket, "dest_path": dest_path})

def download_file_from_gcs(bucket: str, src_path: str, local_path: str) -> None:
    from google.cloud import storage
    client = storage.Client()
    bucket_obj = client.bucket(bucket)
    blob = bucket_obj.blob(src_path)
    blob.download_to_filename(local_path)
    # For logging, use: from logging import log_event
    # log_event("gcs_download", {"bucket": bucket, "src_path": src_path, "local_path": local_path})

# --- Plugin Loader ---
def load_plugins(plugin_dir: str) -> List[str]:
    plugins = []
    for fname in os.listdir(plugin_dir):
        if fname.endswith(".py"):
            mod_name = fname[:-3]
            mod = __import__(f"{plugin_dir.replace('/', '.')}.{mod_name}", fromlist=[mod_name])
            plugins.append(mod_name)
    return plugins

# --- Agent Messaging (API endpoint recommended for real use) ---
def agent_message(agent_id: str, message: str) -> None:
    # In production, this should POST to an agent's API endpoint or use a message broker
    # For logging, use: from logging import log_event
    # log_event("agent_message", {"agent_id": agent_id, "message": message})
    pass

# --- Human in the Loop ---
def human_in_the_loop(prompt: str) -> str:
    # In production, this should trigger a UI or workflow
    return input(prompt)

# --- Notification Utility (stub, to be integrated with notification.py) ---
def notify(channel: str, message: str):
    # For logging, use: from logging import log_event
    # log_event("notification", {"channel": channel, "message": message})
    pass

# --- Health Check Utility ---
def get_system_health() -> Dict[str, Any]:
    health = {"redis": False}
    try:
        health["redis"] = r.ping()
    except Exception:
        health["redis"] = False
    # Add GCS, plugin checks as needed
    return health

def current_timestamp() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

def load_education_from_pinecone(agent_id: str) -> List[str]:
    from utils.vector_memory import PineconeMemory
    try:
        pinecone = PineconeMemory(index_name=f"education-{agent_id}")
        results = pinecone.query(query="*", top_k=5)
        return [r.get("text", "") for r in results]
    except Exception:
        return []

def append_education(agent_id: str, title: str, content: str, tags: Optional[List[str]] = None):
    from utils.vector_memory import PineconeMemory
    try:
        pinecone = PineconeMemory(index_name=f"education-{agent_id}")
        doc = {
            "title": title,
            "content": content,
            "tags": tags or [],
            "timestamp": current_timestamp()
        }
        pinecone.add(text=f"{title}\n{content}", metadata=doc)
        log_event(
            "education_append",
            {"title": title, "tags": tags, "timestamp": doc["timestamp"]},
            agent=agent_id,
            level="INFO"
        )
        return True
    except Exception as e:
        print(f"Error appending education for {agent_id}: {e}")
        return False

def recommend_to_agent(sender_agent_id: str, recipient_agent_id: str, title: str, content: str, tags: Optional[List[str]] = None):
    from utils.vector_memory import PineconeMemory
    try:
        pinecone = PineconeMemory(index_name=f"education-{recipient_agent_id}")
        doc = {
            "title": title,
            "content": content,
            "tags": tags or ["recommendation", sender_agent_id],
            "from_agent": sender_agent_id,
            "timestamp": current_timestamp()
        }
        pinecone.add(text=f"{title}\n{content}", metadata=doc)
        log_event(
            "recommendation",
            {"recipient": recipient_agent_id, "title": title, "tags": tags, "timestamp": doc["timestamp"]},
            agent=sender_agent_id,
            level="INFO"
        )
        return True
    except Exception as e:
        print(f"Error recommending to {recipient_agent_id}: {e}")
        return False

def self_reflect(agent_id: str, identity_context: str) -> Dict[str, str]:
    summary = summarize_text(identity_context, agent_id=agent_id)
    suggestions = generate_outline("How can I grow as an agent?")
    log_event(
        "self_reflect",
        {"summary": summary, "suggestions": suggestions, "timestamp": current_timestamp()},
        agent=agent_id,
        level="INFO"
    )
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": identity_context, "response": summary, "task": "self_reflect"})
    return {
        "summary": summary,
        "suggestions": suggestions
    }

def append_dynamic_identity_note(agent_id: str, note: str):
    from utils.redis_client import get_redis_client
    redis_client = get_redis_client().client
    key = f"identity:notes:{agent_id}"
    timestamped_note = f"- **{current_timestamp()}**: {note}"
    try:
        redis_client.lpush(key, timestamped_note)
        redis_client.ltrim(key, 0, 24)
    except Exception as e:
        print(f"Error appending dynamic identity note for {agent_id}: {e}")

def get_dynamic_identity_notes(agent_id: str) -> List[str]:
    from utils.redis_client import get_redis_client
    redis_client = get_redis_client().client
    key = f"identity:notes:{agent_id}"
    try:
        notes = redis_client.lrange(key, 0, 24)
        return [n.decode('utf-8') if hasattr(n, 'decode') else n for n in notes] if notes else []
    except Exception as e:
        print(f"Error retrieving dynamic identity notes for {agent_id}: {e}")
        return []

# --- Collaboration & Session Tools ---
_SHARED_WHITEBOARD: List[str] = []

def write_whiteboard(text: str) -> None:
    """
    Write a message to the shared whiteboard for collaboration.
    Args:
        text (str): The message or note to add.
    Returns:
        None
    """
    _SHARED_WHITEBOARD.append(text)


def read_whiteboard() -> List[str]:
    """
    Read all messages from the shared whiteboard.
    Returns:
        List[str]: All messages currently on the whiteboard.
    """
    return _SHARED_WHITEBOARD.copy()

_ANNOTATIONS: List[Dict[str, Any]] = []

def add_annotation(target: str, comment: str, author: str) -> None:
    """
    Add a comment/annotation to a text or code block for collaborative review.
    Args:
        target (str): The file or section being annotated.
        comment (str): The annotation text.
        author (str): The agent or user adding the annotation.
    Returns:
        None
    """
    _ANNOTATIONS.append({
        "target": target,
        "comment": comment,
        "author": author,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })

def get_annotations(target: str) -> List[Dict[str, Any]]:
    """
    Get all annotations for a given target (file, section, etc).
    Args:
        target (str): The file or section to retrieve annotations for.
    Returns:
        List[Dict[str, Any]]: List of annotation dicts.
    """
    return [a for a in _ANNOTATIONS if a["target"] == target]

def voting_poll(options: List[str], voters: List[str]) -> Dict[str, int]:
    """
    Simple voting/polling for crew decisions.
    Args:
        options (List[str]): List of options to vote on.
        voters (List[str]): List of voter identifiers.
    Returns:
        Dict[str, int]: Vote counts per option.
    """
    votes = {option: 0 for option in options}
    for voter in voters:
        choice = random.choice(options)
        votes[choice] += 1
    return votes

_SESSION_TIMELINE: List[Dict[str, Any]] = []

def log_session_event(event: str, details: Optional[dict] = None) -> None:
    """
    Log an event to the session/project timeline for audit and review.
    Args:
        event (str): Event description or type.
        details (Optional[dict]): Additional event details.
    Returns:
        None
    """
    _SESSION_TIMELINE.append({
        "event": event,
        "details": details or {},
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })

def get_session_timeline() -> List[Dict[str, Any]]:
    """
    Retrieve the session/project timeline of logged events.
    Returns:
        List[Dict[str, Any]]: List of timeline event dicts.
    """
    return _SESSION_TIMELINE.copy()

def build_reference(topic: str, use_web: bool = True, agent_id: str = "agent") -> Tuple[str, Union[str, None]]:
    """
    Builds a Markdown (.md) and Python (.py) reference file for a given topic.

    Parameters:
        topic (str): The subject to build the reference guide for.
        use_web (bool): Whether to include web search results in the reference.
        agent_id (str): The agent ID for logging and memory pipeline.

    Returns:
        Tuple[str, Union[str, None]]: Paths to the generated Markdown file and Python file,
        or a message indicating no Python file was generated.
    """
    llm = LLMClient()
    pipeline = get_memory_pipeline(agent_id)

    header = f"# Reference Guide: {topic}\n\nGenerated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    body = ""

    if use_web:
        web_results = web_search(topic)
        body += "## Web Summary\n"
        body += web_results
        body += "\n\n"

    gpt_instruction = (
        f"Write a reference guide and code example for the topic '{topic}'. "
        "Begin with a brief explanation in Markdown, followed by a clear Python code block."
    )
    gpt_response = llm.chat(messages=[{"role": "user", "content": gpt_instruction}], agent_id=agent_id)
    log_event("llm_call", {"prompt": gpt_instruction, "response": gpt_response, "task": "build_reference"}, agent=agent_id, level="INFO")
    pipeline.append({"prompt": gpt_instruction, "response": gpt_response, "task": "build_reference"})

    body += gpt_response

    # Save .md
    ref_md_path = Path("reference_code") / f"{topic.replace(' ', '_').lower()}.md"
    ref_md_path.parent.mkdir(parents=True, exist_ok=True)
    with open(ref_md_path, "w") as f:
        f.write(header + body)

    ref_py_path = None
    # Attempt to extract code and save separately
    try:
        code_block = gpt_response.split("```python")[1].split("```")[0].strip()
        ref_py_path = Path("reference_code") / f"{topic.replace(' ', '_').lower()}.py"
        with open(ref_py_path, "w") as f:
            f.write(code_block)
    except Exception:
        code_block = None  # No code block extracted

    if ref_py_path is not None:
        return str(ref_md_path), str(ref_py_path)
    else:
        return str(ref_md_path), "No Python file generated."

def format_council_history_entry(entry: dict) -> str:
    """
    Nicely formats a council/group history entry for display.
    """
    lines = [f"\n[Log Timestamp: {entry['timestamp']} | Event: {entry['event_type']}]"]
    lines.append(f"Prompt: {entry['prompt']}")
    if entry["summary"]:
        lines.append(f"Summary: {entry['summary']}")
    lines.append("Council Responses:")
    for name, response in entry["council_responses"].items():
        lines.append(f"  - {name}: {response[:120]}...")
    if entry["tags"]:
        lines.append(f"Tags: {', '.join(entry['tags'])}")
    return "\n".join(lines)