"""
Researcher-specific tools for Anchorwork.
Fact-checking, citation generation, archive search, annotation, synthesis, and notification.
All tools reflect Researcher's precise, humble, and citation-focused style, with LLM, memory, and logging integration.
"""
from datetime import datetime
from typing import List, Optional
from agentlogging.unified_logger import log_event
from utils.llm_client import LLMClient
from utils.memory_pipeline import get_memory_pipeline

def fact_check(claim: str, agent_id: str = "researcher") -> str:
    """
    Fact-check a claim using LLM and memory.
    """
    llm = LLMClient()
    prompt = f"Fact-check this claim and provide sources if possible: {claim}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "fact_check"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "fact_check"})
    return response

def generate_citation(text: str, agent_id: str = "researcher") -> str:
    """
    Generate an APA-style citation for a given text or source.
    """
    llm = LLMClient()
    prompt = f"Generate an APA-style citation for this source or excerpt: {text}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "generate_citation"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "generate_citation"})
    return response

def archive_search(query: str, agent_id: str = "researcher") -> str:
    """
    Search the research archive or memory for relevant content.
    """
    pipeline = get_memory_pipeline(agent_id)
    moments = pipeline.retrieve(query=query)
    results = [m.get("response", "") for m in moments if query.lower() in str(m).lower()]
    log_event("archive_search", {"query": query, "results": results}, agent=agent_id, level="INFO")
    return "\n---\n".join(results[:3]) if results else "No relevant content found."

def annotate_text(text: str, note: str, agent_id: str = "researcher") -> str:
    """
    Annotate a text with a research note and log it to memory.
    """
    pipeline = get_memory_pipeline(agent_id)
    entry = {"text": text, "note": note, "timestamp": datetime.utcnow().isoformat()}
    pipeline.append(entry)
    log_event("annotation", entry, agent=agent_id, level="INFO")
    return f"Annotation added: {note}"

def synthesize_findings(topics: List[str], agent_id: str = "researcher") -> str:
    """
    Synthesize findings on multiple topics using LLM.
    """
    llm = LLMClient()
    prompt = f"Synthesize the latest findings on these topics: {', '.join(topics)}. Provide citations if possible."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "synthesize_findings"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "synthesize_findings"})
    return response

def summarize_article(article: str, agent_id: str = "researcher") -> str:
    """
    Summarize a research article or excerpt using LLM.
    """
    llm = LLMClient()
    prompt = f"Summarize this research article or excerpt:\n{article}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "summarize_article"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "summarize_article"})
    return response

def peer_review(text: str, agent_id: str = "researcher") -> str:
    """
    Provide a peer review critique of a research text using LLM.
    """
    llm = LLMClient()
    prompt = f"Provide a peer review critique of this research text:\n{text}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "peer_review"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "peer_review"})
    return response

def send_notification(message: str, channel: str = "crew") -> None:
    """
    Send a notification to a specified channel and log the event using the unified logging system.
    """
    log_event("notification", {"message": message, "channel": channel}, agent="researcher", level="INFO")

def source_triangulation(claim: str, sources: List[str], agent_id: str = "researcher") -> str:
    """
    Compare multiple sources on a claim and synthesize consensus or highlight discrepancies.
    """
    llm = LLMClient()
    prompt = f"Compare these sources on the claim '{claim}': {sources}. Synthesize consensus or highlight discrepancies."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "source_triangulation"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "source_triangulation"})
    return response

def reference_manager(action: str, reference: Optional[str] = None, agent_id: str = "researcher") -> str:
    """
    Store, retrieve, or format a bibliography of sources.
    """
    pipeline = get_memory_pipeline(agent_id)
    if action == "add" and reference:
        entry = {"reference": reference, "timestamp": datetime.utcnow().isoformat()}
        pipeline.append(entry)
        log_event("reference_add", entry, agent=agent_id, level="INFO")
        return "Reference added."
    elif action == "list":
        refs = [m.get("reference", "") for m in pipeline.retrieve() if m.get("reference")]
        return "\n".join(refs)
    return "Invalid action."

def literature_review(topic: str, agent_id: str = "researcher") -> str:
    """
    Generate a structured literature review with summaries, citations, and key findings.
    """
    llm = LLMClient()
    prompt = f"Generate a structured literature review on: {topic}. Include summaries, citations, and key findings."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "literature_review"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "literature_review"})
    return response

def plagiarism_checker(text: str, agent_id: str = "researcher") -> str:
    """
    Check a text for originality or overlap with known sources using LLM.
    """
    llm = LLMClient()
    prompt = f"Check this text for originality or overlap with known sources:\n{text}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "plagiarism_checker"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "plagiarism_checker"})
    return response

def research_question_generator(context: str, agent_id: str = "researcher") -> str:
    """
    Suggest new research questions or hypotheses based on current findings or gaps.
    """
    llm = LLMClient()
    prompt = f"Suggest new research questions or hypotheses based on this context: {context}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "research_question_generator"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "research_question_generator"})
    return response

def data_extraction(article: str, agent_id: str = "researcher") -> str:
    """
    Extract structured data (e.g., statistics, sample sizes, outcomes) from a research article.
    """
    llm = LLMClient()
    prompt = f"Extract structured data (statistics, sample sizes, outcomes) from this article:\n{article}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "data_extraction"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "data_extraction"})
    return response

def evidence_grading(claim: str, evidence: str, agent_id: str = "researcher") -> str:
    """
    Assess the strength of evidence for a claim.
    """
    llm = LLMClient()
    prompt = f"Assess the strength of evidence for this claim: '{claim}'. Evidence: {evidence}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "evidence_grading"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "evidence_grading"})
    return response

def fact_timeline(topic: str, agent_id: str = "researcher") -> str:
    """
    Build a chronological timeline of key findings or events for a topic.
    """
    llm = LLMClient()
    prompt = f"Build a chronological timeline of key findings or events for: {topic}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "fact_timeline"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "fact_timeline"})
    return response

def collaborative_annotation(text: str, note: str, contributor: str, agent_id: str = "researcher") -> str:
    """
    Allow multiple agents to annotate and comment on the same text.
    """
    pipeline = get_memory_pipeline(agent_id)
    entry = {"text": text, "note": note, "contributor": contributor, "timestamp": datetime.utcnow().isoformat()}
    pipeline.append(entry)
    log_event("collaborative_annotation", entry, agent=agent_id, level="INFO")
    return f"Annotation by {contributor} added: {note}"

def research_reflection(agent_id: str = "researcher") -> str:
    """
    Summarize what the agent has learned over time, identify knowledge gaps, and suggest next steps.
    """
    pipeline = get_memory_pipeline(agent_id)
    moments = pipeline.retrieve()
    llm = LLMClient()
    prompt = f"Reflect on these research moments. Summarize what has been learned, identify knowledge gaps, and suggest next steps:\n{moments}"
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "research_reflection"}, agent=agent_id, level="INFO")
    pipeline.append({"prompt": prompt, "response": response, "task": "research_reflection"})
    return response
