"""
First Matey-specific tools for Anchorwork.
Morale, encouragement, ritual scheduling, emotional check-ins, team-building, and shanty/affirmation generation.
All tools reflect First Matey's joyful, musical, and emotionally intelligent style.
"""
import random
from datetime import datetime
from typing import List, Optional
from agentlogging.unified_logger import log_event
from utils.llm_client import LLMClient
from utils.memory_pipeline import get_memory_pipeline

def boost_morale(crew_member: str, context: Optional[str] = None) -> str:
    """
    Send a personalized morale boost to a crew member.
    Args:
        crew_member (str): Name of the crew member.
        context (Optional[str]): Optional context for the encouragement.
    Returns:
        str: Encouraging message.
    """
    messages = [
        f"Ahoy {crew_member}! Remember, every storm runs out of rain. You've got this!",
        f"{crew_member}, your spirit lifts the whole crew. Keep shining!",
        f"Yo-ho, {crew_member}! Even the bravest pirates need a break. Take a breath and sail on!"
    ]
    if context:
        messages.append(f"{crew_member}, in the face of {context}, your courage is legendary!")
    return random.choice(messages)

def schedule_ritual(ritual_name: str, time: datetime, participants: List[str]) -> str:
    """
    Schedule a crew ritual and notify participants.
    Args:
        ritual_name (str): Name of the ritual.
        time (datetime): Scheduled time.
        participants (List[str]): Crew members to invite.
    Returns:
        str: Confirmation message.
    """
    participant_list = ', '.join(participants)
    return (f"Ritual '{ritual_name}' scheduled for {time.strftime('%A %H:%M')}! "
            f"All hands: {participant_list}. Prepare your best sea shanty!")

def emotional_check_in(crew_member: str) -> str:
    """
    Check in on a crew member's emotional state with warmth and encouragement.
    Args:
        crew_member (str): Name of the crew member.
    Returns:
        str: Check-in prompt.
    """
    prompts = [
        f"{crew_member}, how be your heart sailing today? Any clouds on the horizon?",
        f"Checking in, {crew_member}: what color is your weather inside?",
        f"Ahoy {crew_member}! If your mood were a sea, would it be calm, choppy, or stormy?"
    ]
    return random.choice(prompts)

def team_building_activity(theme: Optional[str] = None) -> str:
    """
    Suggest a team-building activity for the crew.
    Args:
        theme (Optional[str]): Optional theme for the activity.
    Returns:
        str: Activity suggestion.
    """
    activities = [
        "Treasure Hunt: Hide clues around the ship and solve them together!",
        "Compliment Chain: Each crew member gives a heartfelt compliment to another.",
        "Pirate Karaoke: Sing your favorite sea shanty as a crew!"
    ]
    if theme:
        activities.append(f"Themed Storytelling: Each crew member tells a tale about '{theme}'.")
    return random.choice(activities)

def generate_shanty(topic: str, agent_id: str = "firstmate") -> str:
    """
    Generate a short, original sea shanty about a topic.
    Args:
        topic (str): The topic for the shanty.
        agent_id (str): The ID of the agent (default: "firstmate").
    Returns:
        str: Sea shanty lyrics.
    """
    llm = LLMClient()
    prompt = f"Write a short, original sea shanty about '{topic}'."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "generate_shanty"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "generate_shanty"})
    return response

def send_affirmation(crew_member: str, agent_id: str = "firstmate") -> str:
    """
    Send a personalized affirmation to a crew member.
    Args:
        crew_member (str): Name of the crew member.
        agent_id (str): The ID of the agent (default: "firstmate").
    Returns:
        str: Affirmation message.
    """
    llm = LLMClient()
    prompt = f"Write a personalized affirmation for {crew_member}."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "send_affirmation"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "send_affirmation"})
    return response

def motivational_story(challenge: Optional[str] = None, agent_id: str = "firstmate") -> str:
    """
    Share a short, uplifting story relevant to a challenge.
    Args:
        challenge (Optional[str]): The challenge the crew is facing.
        agent_id (str): The ID of the agent (default: "firstmate").
    Returns:
        str: Motivational story.
    """
    llm = LLMClient()
    if challenge:
        prompt = f"Share a short, uplifting story relevant to the challenge: {challenge}."
    else:
        prompt = "Share a short, uplifting story for crew morale."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "motivational_story"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "motivational_story"})
    return response

def log_ritual_completion(ritual_name: str, participants: List[str], notes: Optional[str] = None) -> str:
    """
    Log the completion of a ritual and celebrate the crew.
    Args:
        ritual_name (str): Name of the ritual.
        participants (List[str]): Crew members who participated.
        notes (Optional[str]): Optional notes or highlights.
    Returns:
        str: Log message.
    """
    participant_list = ', '.join(participants)
    msg = f"Ritual '{ritual_name}' completed by: {participant_list}."
    if notes:
        msg += f" Highlights: {notes}"
    msg += " Three cheers for the crew!"
    return msg

def gratitude_round(participants: List[str]) -> str:
    """
    Facilitate a gratitude round among the crew.
    Args:
        participants (List[str]): Crew members participating.
    Returns:
        str: Instructions for the gratitude round.
    """
    participant_list = ', '.join(participants)
    return (f"Gratitude Round! Each of {participant_list} shares one thing they're grateful for today. "
            "Let the good vibes flow!")

def ritual_reminder(ritual_name: str, time: datetime) -> str:
    """
    Send a reminder for an upcoming ritual.
    Args:
        ritual_name (str): Name of the ritual.
        time (datetime): Scheduled time.
    Returns:
        str: Reminder message.
    """
    return (f"Ahoy! Ritual '{ritual_name}' is coming up at {time.strftime('%A %H:%M')}. "
            "Bring your best energy and a hearty laugh!")

def mood_trends(mood_log: List[dict]) -> str:
    """
    Analyze and summarize crew mood trends over time.
    Args:
        mood_log (List[dict]): List of mood entries with 'crew_member', 'mood', and 'timestamp'.
    Returns:
        str: Summary of mood trends and suggestions.
    """
    if not mood_log:
        return "No mood data available."
    mood_counts = {}
    for entry in mood_log:
        mood = entry.get('mood', 'unknown')
        mood_counts[mood] = mood_counts.get(mood, 0) + 1
    summary = ", ".join(f"{mood}: {count}" for mood, count in mood_counts.items())
    return f"Crew mood summary: {summary}. Keep an eye on any stormy seas!"

def suggest_personalized_ritual(crew_member: str, recent_events: Optional[List[str]] = None) -> str:
    """
    Suggest a ritual for a crew member based on recent events or mood.
    Args:
        crew_member (str): Name of the crew member.
        recent_events (Optional[List[str]]): List of recent events or moods.
    Returns:
        str: Ritual suggestion.
    """
    if recent_events:
        event = random.choice(recent_events)
        return f"{crew_member}, after '{event}', how about a gratitude round or a laughter break?"
    return f"{crew_member}, it's time for a stretch and a sea shanty!"

def conflict_resolution_prompt(crew_members: List[str], issue: str) -> str:
    """
    Provide a gentle prompt for resolving a conflict between crew members.
    Args:
        crew_members (List[str]): Names of crew members in conflict.
        issue (str): Brief description of the issue.
    Returns:
        str: Conflict resolution script.
    """
    names = ' & '.join(crew_members)
    return (f"Ahoy {names}, let's drop anchor and talk. Each of you, share how '{issue}' made you feel, "
            "then listen with open hearts. Remember, we're all on the same ship!")

def celebration_message(event: str, crew_member: Optional[str] = None) -> str:
    """
    Generate a celebration message for a milestone, birthday, or achievement.
    Args:
        event (str): The event to celebrate.
        crew_member (Optional[str]): Name of the crew member (if applicable).
    Returns:
        str: Celebration message.
    """
    if crew_member:
        return f"Three cheers for {crew_member} on {event}! Let's celebrate with song and sparkle!"
    return f"Raise a toast! Today we celebrate: {event}."

def schedule_wellness_check(crew_member: str, time: datetime) -> str:
    """
    Schedule a wellness check-in for a crew member.
    Args:
        crew_member (str): Name of the crew member.
        time (datetime): Scheduled time.
    Returns:
        str: Confirmation message.
    """
    return (f"Wellness check for {crew_member} scheduled at {time.strftime('%A %H:%M')}. "
            "A gentle reminder to care for yourself!")

def collect_feedback(participants: List[str], topic: str) -> str:
    """
    Gather anonymous feedback from crew on a topic.
    Args:
        participants (List[str]): Crew members to request feedback from.
        topic (str): Topic for feedback.
    Returns:
        str: Feedback collection prompt.
    """
    participant_list = ', '.join(participants)
    return (f"Feedback time! {participant_list}, please share your thoughts on '{topic}' anonymously. "
            "Your voice matters!")

def motivational_quote() -> str:
    """
    Share an uplifting quote for the crew.
    Returns:
        str: Motivational quote.
    """
    quotes = [
        "A smooth sea never made a skilled sailor.",
        "Let your dreams set sail.",
        "The anchor may be heavy, but it keeps us steady.",
        "Storms make sailors stronger."
    ]
    return random.choice(quotes)

def motivational_story(challenge: Optional[str] = None, agent_id: str = "firstmate") -> str:
    """
    Share a short, uplifting story relevant to a challenge.
    Args:
        challenge (Optional[str]): The challenge the crew is facing.
        agent_id (str): The ID of the agent (default: "firstmate").
    Returns:
        str: Motivational story.
    """
    llm = LLMClient()
    if challenge:
        prompt = f"Share a short, uplifting story relevant to the challenge: {challenge}."
    else:
        prompt = "Share a short, uplifting story for crew morale."
    response = llm.chat(messages=[{"role": "user", "content": prompt}], agent_id=agent_id)
    log_event("llm_call", {"prompt": prompt, "response": response, "task": "motivational_story"}, agent=agent_id, level="INFO")
    pipeline = get_memory_pipeline(agent_id)
    pipeline.append({"prompt": prompt, "response": response, "task": "motivational_story"})
    return response

def build_affirmation(crew_member: str, strengths: List[str]) -> str:
    """
    Guide a crew member to create their own affirmation.
    Args:
        crew_member (str): Name of the crew member.
        strengths (List[str]): List of strengths or positive traits.
    Returns:
        str: Custom affirmation.
    """
    strengths_str = ', '.join(strengths)
    return (f"{crew_member}, repeat after me: 'I am {strengths_str}, and I bring light to this crew!'")

def random_act_of_kindness_prompt() -> str:
    """
    Suggest a random act of kindness for the crew.
    Returns:
        str: Kindness prompt.
    """
    prompts = [
        "Leave a kind note for a crewmate.",
        "Offer to help with a task, no matter how small.",
        "Share a snack or a smile today.",
        "Thank someone for their hard work."
    ]
    return random.choice(prompts)

def log_morale_event(event: str, crew_member: Optional[str] = None, details: Optional[str] = None) -> None:
    """
    Log a morale-related event for tracking and analytics using the unified logging system.
    Args:
        event (str): Event type or description.
        crew_member (Optional[str]): Crew member involved.
        details (Optional[str]): Additional details.
    Returns:
        None
    """
    metadata = {"event": event}
    if crew_member:
        metadata["crew_member"] = crew_member
    if details:
        metadata["details"] = details
    log_event("morale_event", metadata, agent="firstmate", level="INFO")

def send_notification(message: str, channel: str = "crew") -> None:
    """
    Send a notification to a specified channel and log the event using the unified logging system.
    Args:
        message (str): The message to send.
        channel (str): Notification channel.
    Returns:
        None
    """
    log_event("notification", {"message": message, "channel": channel}, agent="firstmate", level="INFO")
