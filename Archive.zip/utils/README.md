# Unified Redis Management (May 2025 Update)

**All Redis connection, Streams, and Stack logic is now unified in `redis_managers.py`.**

- Use `redis_managers.py` for all Redis operations: connections, Streams (event logging, system logs, user interactions, memory updates), and Stack features (Bloom filters, TimeSeries, JSON, metrics).
- The following legacy modules are now deprecated and should be removed after migration:
  - `redis_client.py`
  - `redis_streams.py`
  - `redis_stack.py`
  - `agentlogging/redis_logger.py`
- Update all imports to use `from utils.redis_managers import ...`.
- See `redis_managers.py` for:
  - `AnchorworkRedisClient` (singleton connection)
  - `RedisStreamsManager` (streams/events)
  - `RedisStackManager` (Bloom, TimeSeries, JSON)
  - `LoggingMetrics` (metrics, deduplication)

**Example Usage:**
```python
from utils.redis_managers import RedisStreamsManager, RedisStackManager, LoggingMetrics
streams = RedisStreamsManager()
stack = RedisStackManager()
metrics = LoggingMetrics()

streams.publish_agent_event(agent_id, event_type, data)
stack.create_bloom_filter('myfilter')
metrics.record_log_event('api_call')
```

# utils/ Anchorwork Utilities

This folder contains core backend utilities for Anchorwork agents and services. These modules provide memory, logging, code analysis, route inspection, system command execution, and more. All are designed for safety, auditability, and extensibility.

## Major Utilities

### 1. **memory_pipeline.py**
- **Purpose:** Implements a multi-tiered memory system inspired by human cognition, supporting Sensory, Short-Term, Working, and Long-Term memory for agents.
- **Architecture:**
  - **Sensory Memory:** Ephemeral, ms–s, stores raw inputs (via Redis Streams).
  - **Short-Term Memory (STM):** 15–30s, buffer for recent entries (Redis List/Stream).
  - **Working Memory:** Active manipulation and chaining (LivingMemory, Redis Stream for live goals/state).
  - **Long-Term Memory (LTM):** Multi-tiered, durable, semantic-indexed facts and experiences. LTM is not minimal: it can include active, archive, and summary tiers (e.g., Pinecone vector indexes for both active and archived memory, plus summary files for agent recall).
- **Pipeline Flow:**
  - On interaction: append to all memory layers (sensory, STM, working, LTM).
  - On retrieval: combine fragments from all layers for context.
- **Backends:** Redis for short-lived memory, Pinecone for long-term (with both active and archive indexes), JSONL for fallback.
- **Agent-Specific Storage:**
  - Summaries of what has happened ("moments") are stored in each agent's memory folder (e.g., `memory/agent_id/`).
  - Education appends (e.g., via `education_append`) are stored in each agent's education folder (e.g., `memory/agent_id/education/`).
- **Usage Example:**
  ```python
  from utils.memory_pipeline import get_memory_pipeline
  pipeline = get_memory_pipeline(agent_id="coder")
  pipeline.append(moment)
  context = pipeline.retrieve_context(query="fix bug")
  ```
- **Improvements:** Structured logging, robust error handling, async wrappers, batch support.
- **Best Practices:**
  - Use `get_memory_pipeline` for all agent memory operations.
  - Store important events in LTM (active/archive/summary) as appropriate for agent recall and semantic search.
  - Use agent-specific folders for memory and education to keep context organized and persistent.

### 2. **static_analysis.py**
- Centralized static analysis (ruff, mypy, pylint, bandit) for code quality.
- Used by coder agent/tools for linting and type checks.
- Improvements: Moved coder-specific wrappers to coder_tools.py for agent safety.

### 3. **route_inspector.py**
- Discovers, analyzes, and documents all API routes in the codebase.
- Outputs Markdown or JSON documentation, with coverage analysis and improvement suggestions.
- CLI support for automation; logs all actions via `log_event`.
- Improvements: Structured logging, JSON output, CLI, persistent disk support.

### 4. **system_runner.py**
- Safe, auditable system command execution with allow-list and logging.
- Used by all agents via `BaseAgent.system_runner`.
- Improvements: Structured logging, async support, user/session context, output truncation.

### 5. **vector_memory.py**
- Pinecone-based vector memory for agent long-term semantic storage and for the anchorwork core semantic search (file base).
- **Anchorwork Core Data:** The core semantic knowledge base (for similarity search, RAG, etc.) is stored in Pinecone, not in the relational DB. This enables fast, flexible, and scalable semantic retrieval for agents.
- **Hybrid/Hierarchical Storage:**
  - **Agent-Specific Folders:** Each agent has a folder (e.g., `/data/memory/coder/`) for persistent, chronological summaries ("moments") and education (`/data/memory/coder/education/`).
  - **Pinecone:** Used for semantic search and recall (active/archive/summary tiers). **Best Practice:** On every important event/session, summarize and:
    1. Save the summary as a text file in the agent's memory folder (for audit, backup, and chronological review).
    2. Upsert the summary to Pinecone for semantic recall (for fast, similarity-based retrieval).
  - **Hybrid Retrieval:**
    - When an agent needs to recall a summary, it should:
      1. Search its local memory folder (`/data/memory/agent_id/`) for relevant summaries (by filename, timestamp, or keyword).
      2. If not found or not relevant, fall back to Pinecone for semantic search.
    - This ensures fast access to recent/important summaries and scalable recall for older or semantically relevant memories.
  - **Scheduled Upsert/Prune:**
    - Use a cron job or scheduled task to batch-upload new summaries to Pinecone and prune old files from `/data/memory/agent_id/` (e.g., keep only the last N files or files newer than X days).
  - **Education:** Education events should be appended to `/data/memory/agent_id/education/` and optionally upserted to Pinecone for semantic search.
- **Persistent Disk Setup:**
  - On Render, add a persistent disk (e.g., 10GB) and mount it at `/data`.
  - Update your agent code to use `/data/memory/agent_id/` for all persistent agent storage.
  - This keeps your codebase clean and allows for scalable, safe memory storage.
- Role-based access, batch ops, health checks, structured logging.
- Improvements: Logging, batch/async support, metadata enforcement.
- **Best Practices:**
  - Use Pinecone for all semantic search, vector-based retrieval, and core knowledge base storage.
  - Use PostgreSQL (db_logger.py) for structured logs, analytics, and compliance—not for semantic core data.
  - If you need to cross-reference, store Pinecone vector IDs or metadata in the DB for traceability.
  - For hybrid/hierarchical storage, keep summaries and references in agent folders, but use Pinecone for all similarity-based lookups.
  - Regularly prune or archive old files in `/data/memory/` to manage disk usage.

## Setup Instructions

1. **Add a Persistent Disk on Render:**
   - Go to your Render dashboard, add a persistent disk (e.g., 10GB) and mount it at `/data`.
2. **Update Agent Code:**
   - Ensure all agent memory and education writes go to `/data/memory/agent_id/` and `/data/memory/agent_id/education/`.
   - Use `os.makedirs(..., exist_ok=True)` before writing files.
3. **Configure Pinecone:**
   - Set up Pinecone API keys and environment variables as needed.
   - Use Pinecone for all semantic search and core knowledge base storage.
4. **Prune/Manage Memory Folders:**
   - Implement pruning scripts or cron jobs to limit the number of files or total disk usage in `/data/memory/`.
5. **Download Files as Needed:**
   - Use SSH/SCP/SFTP to download files from `/data/` to your local machine.
6. **(Optional) Automate Exports:**
   - Use cron jobs or Render jobs to schedule regular exports, backups, or email/cloud uploads.

## Improvements Made
- Structured logging (`log_event`) added to all major utilities.
- JSON output and CLI support for route inspection.
- Persistent disk support for file outputs (e.g., `/data/routes.json`).
- Async and batch support for memory and system commands.
- Cost-aware, safe model and system command usage.

## Ongoing/Future Work
- Further integration of cloud storage/email for automated file delivery.
- Enhanced parameter/type extraction in route inspection.
- More agent-facing wrappers in tools/shared.py for utility access.
- Improved test coverage and error reporting.
- More robust CI/CD integration for agent-driven code changes.

## Usage Notes
- All agents should use these utilities via imports, not by duplicating logic.
- Output files should be saved to `/data/` for persistence and easy retrieval.
- Use SSH/SCP/SFTP to download files from Render persistent disk to your local machine.
- For automation, use cron jobs or Render jobs to schedule regular exports or reports.

## OneDrive/Section-Based Workflow for Agent-Human Collaboration

If you want to collaborate with an agent (e.g., Cartographer) on a massive manual and ensure seamless, cohesive editing with Microsoft Word:

### Recommended Workflow

1. **Folder & File Structure**
   - Organize the manual so each chapter is a folder, and each section is its own `.docx` file.
   - Example: `/Manual/Chapter01/01_Intro.docx`

2. **OneDrive for Sync**
   - Store the entire project folder in OneDrive, so all files are kept up-to-date across your devices and the cloud.
   - Any change (by agent or human) syncs automatically.

3. **Agent-Driven Edits**
   - Cloud agent (on Render or elsewhere) accesses only one section file at a time via the Microsoft Graph API.
   - Agent downloads the target section, applies edits, and uploads it back to OneDrive.
   - Only a handful of API requests per edit—no risk of hitting API limits unless editing hundreds of sections at once.

4. **Human Review**
   - As soon as the file is synced, you open the section in Word and see the full, formatted output.
   - You can review, further edit, or approve changes, all within Word.

5. **Conflict Avoidance**
   - This approach minimizes file conflicts and sync errors.
   - To avoid “conflicted copies,” coordinate so only one editor (agent or human) works on a section at a time.
   - Consider keeping a tracker/spreadsheet for edit status.

6. **Benefits**
   - Scalable: Easily supports massive manual projects.
   - Efficient: Keeps API usage and cloud agent tokens low.
   - Immediate Review: You see edits in MS Word as soon as they sync.
   - Robust: Reduces risk of data loss or merge conflicts.
   - Collaborative: Multiple people or agents can work in parallel (one per section).

7. **Extra Tips**
   - Use consistent file naming for easy automation.
   - Utilize OneDrive’s version history for safety.
   - Optionally, enable “track changes” so you can see agent edits in Word.
   - Set up notifications (email, desktop, etc.) for agent-completed edits if needed.

---

This section-by-section, OneDrive-synced workflow gives you the best of all worlds:
- Powerful cloud-based AI for writing/editing,
- Full-featured formatting and review in MS Word,
- Scalability and safety for your massive manual.

---

## Recent Updates (May 2025)

- **Unified Redis Managers:** All Redis connection, Streams, and Stack logic is now in `redis_managers.py`. Use this for all Redis operations (including event logging, Bloom filters, TimeSeries, and JSON).
- **MemoryMover:** The background worker for memory summarization and movement is now `MemoryMover` (`memory_mover.py`).
- **Watcher Monitoring:** The Watcher agent now monitors memory health and background jobs, with tools in `agents/watcher/watcher_tools.py`.
- **Legacy Cleanup:** Old Redis modules (`redis_client.py`, `redis_streams.py`, `redis_stack.py`) are being migrated into the unified manager. Update all imports accordingly.

---

## Handoff Summary

- Use `redis_managers.py` for all Redis operations.
- Use `MemoryMover` for background memory summarization.
- Watcher agent is responsible for monitoring memory and job health.
- Remove or refactor any direct usage of old Redis modules after migration is complete.

See the main `README.md` for a high-level summary and next steps.

_Last updated: May 31, 2025_